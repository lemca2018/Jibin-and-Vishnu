package com.example.jibinbaby.lockit2;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class LiatAll1 extends AppCompatActivity {
    SQLiteDatabase db;
    ListView lv;
    Context mContext;
    EditText editText;
    String nm;
    String nml="Albin";
    ArrayAdapter<String> ada;
    ArrayList<String> list=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liat_all1);
        mContext = this;
        lv = (ListView) findViewById(R.id.listView);
        //editText = (EditText) findViewById(R.id.txtSearch);
        db = openOrCreateDatabase("LockItDB2", Context.MODE_PRIVATE, null);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LiatAll1.this,AddContacts.class);
                startActivity(intent);
            }
        });
        FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(LiatAll1.this,Searchlist.class);
                startActivity(intent3);
            }
        });
        String query = "CREATE TABLE IF NOT EXISTS contacts5(id INTEGER PRIMARY KEY AUTOINCREMENT,name VARCHAR,number VARCHAR,email VARCHAR);";
        db.execSQL(query);
        Cursor cur = db.rawQuery("SELECT * FROM contacts5 ORDER BY name ASC", null);
        if (cur.getCount() != 0) {
            cur.moveToFirst();
            int c = cur.getCount();
            for (int i = 0; i < c; i++) {
                nm = cur.getString((cur.getColumnIndex("name")));
                nml += "," + nm;
                list.add(nm);
                cur.moveToNext();
            }
                ada = new ArrayAdapter<String>(mContext, android.R.layout.simple_list_item_1, list);
                lv.setAdapter(ada);
                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent in=new Intent(LiatAll1.this,DetailsBasic.class);
                        in.putExtra("name", (String) parent.getItemAtPosition(position));
                       // Toast.makeText(getApplicationContext(),(String) parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                        startActivity(in);
                    }
                });

            }
    }

}
